import logging
import os

from twisted.internet import reactor
from twisted.logger import (
    globalLogBeginner,
    STDLibLogObserver,
    FilteringLogObserver,
    LogLevelFilterPredicate,
    LogLevel,
)

from itu import context, bread

HOME = "~/Desktop/dev/idena-telegram-updater/"

logger = logging.getLogger(__name__)

def identify_pass():
    logger.info("Identified successfully!")
    exit()

def identify_fail():
    logger.warning("Failed to Identify Address")
    exit()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    filtering = FilteringLogObserver(
        STDLibLogObserver(), [LogLevelFilterPredicate(defaultLogLevel=LogLevel.warn)]
    )
    globalLogBeginner.beginLoggingTo([filtering])

    ctx = context.init_context(HOME, reactor)
    br = bread.Bread(ctx)

    d = br.setup()
    d.addCallbacks(identify_pass, identify_fail, callbackArgs)
    reactor.run()
