import logging
import json
from datetime import datetime, timedelta

import attr
from twisted.internet import defer

from idenaTelegramUpdater import idena, telegramWrapper


logger = logging.getLogger(__name__)

RELOAD_TIME = 300


@attr.s
class Worker:
    ctx = attr.ib()
    _idena = attr.ib(default=None)
    _tele = attr.ib(default=None)

    def setup(self):
        """
        Setup for getting bread.

        Returns Idena identity deferred
        """
        logger.info("Waking up to get that bread...")
        self.ctx.reactor.callLater(RELOAD_TIME, self._reload_config)

        self._idena = idena.Idena(self.ctx)
        self._tele = telegramWrapper.TelegramWrapper(self.ctx)
        if self._idena.setup() and self._tele.setup():
            return self._idena.identify()

        return defer.fail("All parameters must be filled in")

    def _reload_config(self):
        """ Reloads the config file from home """
        self.ctx.config = context.load_config(self.ctx.home)
        self.ctx.reactor.callLater(RELOAD_TIME, self._reload_config)

    def _balance_cb(self, response):
        """
        Callback for balance deferred.
        If balance found, a telegram message is sent.
        Else return None
        """
        res = json.loads(response)
        if "result" not in res and "balance" not in res["result"]:
            logger.info("Balance Not Found!")
            return

        logger.info(
            "Balance found stake={}: balance={}".format(
                float(res["result"]["stake"]), float(res["result"]["balance"])
            )
        )

        self._tele.send_balance(
            float(res["result"]["balance"]), float(res["result"]["stake"])
        )

    def _balance_err(self, failure):
        """ Balance errBack, print failure and return"""
        logger.warning("Failed to get balance")
        logger.warning(failure.getErrorMessage())
        return

    def __call__(self, time):
        """ Call balance and send a telegram-message """
        self.ctx.reactor.callLater(30, self)
        d = self._idena.balance()
        d.addCallbacks(self._balance_cb, self._balance_err)
        return
