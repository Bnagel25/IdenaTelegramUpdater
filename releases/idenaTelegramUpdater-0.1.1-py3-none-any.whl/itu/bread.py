import logging

import attr

from itu import idena


logger = logging.getLogger(__name__)

@attr.s
class Bread:
    ctx = attr.ib()
    _idena = attr.ib(default=None)

    def setup(self):
        logger.info("Waking up to get that bread...")
        self._idena = idena.Idena(self.ctx)
        return self._idena.identify()

    def __call__(self):
        logger.info("")
