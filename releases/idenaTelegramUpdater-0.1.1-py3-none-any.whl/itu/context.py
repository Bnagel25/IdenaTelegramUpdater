import os
import logging
import json

import attr

logger = logging.getLogger(__name__)

CONFIG_FILE = "sample-config.json"

@attr.s
class Context:
    """
    Application Context
    """

    reactor = attr.ib()
    config = attr.ib()


@attr.s
class Config:
    """
    Application Config
    """

    nodeAddress = attr.ib(default="", validator=attr.validators.instance_of(str))
    nodeApiKey = attr.ib(default="", validator=attr.validators.instance_of(str))
    nodeHost = attr.ib(default="")
    nodePort = attr.ib(default="")
    command = attr.ib(default="",  validator=attr.validators.instance_of(str))
    updateTimes = attr.ib(default=[])


def _update_config(old, changes):
    """Update configuration with new values"""
    valid_keys = {f.name for f in attr.fields(Config)}
    requested_keys = set(changes.keys())
    change_keys = valid_keys.intersection(requested_keys)

    to_apply = {}
    for k in change_keys:
        to_apply[k] = changes[k]

    try:
        newconfig = attr.evolve(old, **to_apply)
    except Exception:
        logger.exception("Unable to apply config changes")
        raise
    else:
        return newconfig


def load_config(home):
    """Load the configuration from disk or use the default.

    Note that if the saved configuration contains an invalid value,
    the entire saved configuration is deemed untrustworthy and discarded.
    """
    filename = os.path.join(home, CONFIG_FILE)
    default = Config()

    try:
        saved = json.loads(filename)
    except Exception as e:
        logger.warning("Unable to load config file: %s", str(e))
        return default

    try:
        new = _update_config(default, saved)
    except Exception:
        logger.exception("Unable to use saved configuration, reverting to default")
        return default
    else:
        return new

def init_context(home, reactor):
    """Initialize the application context."""
    config = load_config(home)
    return Context(reactor, config)
