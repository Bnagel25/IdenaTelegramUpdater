import logging

from twisted.web.client import Agent
import attr

logger = logging.getLogger(__name__)

IDENTIFY = "dna_identity"
BALANCE = "dna_getBalance"
EPOCH = "dna_epoch"

@attr.s
class Idena:
    ctx = attr.ib()
    _conn = attr.ib(default=None)
    _agent = attr.ib(default=None)

    def _build_payload(self, method):
        """ Builds the POST body """
        return {
            "key": self.ctx.config.nodeApiKey,
            "method": "method",
            "params": [self.ctx.config.nodeAddress],
            "id": 1
        }

    def _post(self, payload):
        """
        Posts request through twisted agent.

        Returns deferred
        """
        if not self._agent:
            self._agent = Agent(self.ctx.reactor)

        d = self._agent.request(
            b'POST',
            b'http://{}:{}'.format(self.ctx.config.nodeHost, self.ctx.config.nodePort),
            payload
        )
        return d


    def identify(self):
        """
        Send post request for identity provided

        Return deferred
        """
        d = self._post(self._build_payload(IDENTIFY))
        return d
